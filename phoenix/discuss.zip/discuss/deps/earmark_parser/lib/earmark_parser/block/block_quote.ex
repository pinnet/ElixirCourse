defmodule EarmarkParser.Block.BlockQuote do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, blocks: []
end
#  SPDX-License-Identifier: Apache-2.0
