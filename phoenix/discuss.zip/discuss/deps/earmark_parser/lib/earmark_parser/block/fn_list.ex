defmodule EarmarkParser.Block.FnList do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: ".footnotes", blocks: []
end
#  SPDX-License-Identifier: Apache-2.0
