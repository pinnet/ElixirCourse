defmodule EarmarkParser.Block.FnDef do
  @moduledoc false
  defstruct lnb: 0, annotation: nil, attrs: nil, id: nil, number: nil, blocks: []
end
#  SPDX-License-Identifier: Apache-2.0
