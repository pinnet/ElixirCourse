defmodule EarmarkParser.Block.Text do
  @moduledoc false
  defstruct attrs: nil, lnb: 0, annotation: nil, line: ""
end
#  SPDX-License-Identifier: Apache-2.0
