[
  inputs: [
    "*.exs",
    "lib/**/*.ex",
    "test/**/*.{ex,exs}"
  ]
]
